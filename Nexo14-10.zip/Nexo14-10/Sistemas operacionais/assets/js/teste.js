function configurarModal(openId, modalId, closeId) {
  const openBtn = document.getElementById(openId);
  const modal = document.getElementById(modalId);
  const closeBtn = document.getElementById(closeId);

  openBtn.addEventListener('click', () => {
    modal.style.display = 'flex';
  });

  closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
  });

  window.addEventListener('click', (e) => {
    if (e.target === modal) modal.style.display = 'none';
  });
}

// Configura cada modal separadamente
configurarModal('openModalJava', 'modalJava', 'closeModalJava');
configurarModal('openModalCsharp', 'modalCsharp', 'closeModalCsharp');