// redesSociais.js - ARQUIVO COMPLETO ATUALIZADO

// Dados das redes sociais com suporte a múltiplos idiomas
const redesSociaisInfo = {
    'instagram': {
        nome: {
            'pt': 'Instagram',
            'en': 'Instagram'
        },
        criador: 'Kevin Systrom e Mike Krieger',
        anoCriacao: 2010,
        usuarios: {
            'pt': '1.4 bilhões',
            'en': '1.4 billion'
        },
        descricao: {
            'pt': 'Plataforma para compartilhamento de fotos e vídeos. Permite que usuários publiquem conteúdos, sigam outros usuários e interajam através de likes e comentários.',
            'en': 'Platform for sharing photos and videos. Allows users to publish content, follow other users and interact through likes and comments.'
        }
    },
    'youtube': {
        nome: {
            'pt': 'YouTube',
            'en': 'YouTube'
        },
        criador: 'Chad Hurley, Steve Chen e Jawed Karim',
        anoCriacao: 2005,
        usuarios: {
            'pt': '2.5 bilhões',
            'en': '2.5 billion'
        },
        descricao: {
            'pt': 'Maior plataforma de compartilhamento de vídeos do mundo. Permite upload, visualização e compartilhamento de conteúdos em vídeo de todos os tipos.',
            'en': 'Largest video sharing platform in the world. Allows uploading, viewing and sharing of all types of video content.'
        }
    },
    'facebook': {
        nome: {
            'pt': 'Facebook',
            'en': 'Facebook'
        },
        criador: 'Mark Zuckerberg',
        anoCriacao: 2004,
        usuarios: {
            'pt': '2.9 bilhões',
            'en': '2.9 billion'
        },
        descricao: {
            'pt': 'Rede social que conecta pessoas ao redor do mundo. Permite compartilhamento de textos, fotos, vídeos e criação de comunidades e grupos.',
            'en': 'Social network that connects people around the world. Allows sharing of texts, photos, videos and creation of communities and groups.'
        }
    },
    'whatsapp': {
        nome: {
            'pt': 'WhatsApp',
            'en': 'WhatsApp'
        },
        criador: 'Jan Koum e Brian Acton',
        anoCriacao: 2009,
        usuarios: {
            'pt': '2 bilhões',
            'en': '2 billion'
        },
        descricao: {
            'pt': 'Aplicativo de mensagens instantâneas que permite troca de textos, fotos, vídeos e chamadas de voz e vídeo através da internet.',
            'en': 'Instant messaging application that allows exchange of texts, photos, videos and voice and video calls over the internet.'
        }
    },
    'tiktok': {
        nome: {
            'pt': 'TikTok',
            'en': 'TikTok'
        },
        criador: 'Zhang Yiming',
        anoCriacao: 2016,
        usuarios: {
            'pt': '1.2 bilhões',
            'en': '1.2 billion'
        },
        descricao: {
            'pt': 'Plataforma de vídeos curtos e entretenimento. Focada em conteúdos criativos de 15 a 60 segundos com efeitos especiais e trilhas sonoras.',
            'en': 'Short video and entertainment platform. Focused on creative content from 15 to 60 seconds with special effects and soundtracks.'
        }
    },
    'discord': {
        nome: {
            'pt': 'Discord',
            'en': 'Discord'
        },
        criador: 'Jason Citron',
        anoCriacao: 2015,
        usuarios: {
            'pt': '350 milhões',
            'en': '350 million'
        },
        descricao: {
            'pt': 'Plataforma de comunicação voltada para comunidades e gamers. Oferece chat por texto, voz e vídeo em servidores organizados por canais.',
            'en': 'Communication platform focused on communities and gamers. Offers text, voice and video chat in servers organized by channels.'
        }
    }
};

// Função para abrir o pop-up
function abrirPopup(redeSocial) {
    const info = redesSociaisInfo[redeSocial];
    if (!info) return;
    
    const currentLang = languageManager ? languageManager.currentLang : 'pt';
    
    // Criar o overlay do pop-up
    const overlay = document.createElement('div');
    overlay.className = 'popup-overlay';
    overlay.innerHTML = `
        <div class="popup-content">
            <button class="fechar-popup">&times;</button>
            <h2>${getTranslatedValue(info.nome, currentLang)}</h2>
            <div class="popup-info">
                <p><strong>${getPopupLabel('criador', currentLang)}</strong> ${info.criador}</p>
                <p><strong>${getPopupLabel('ano_criacao', currentLang)}</strong> ${info.anoCriacao}</p>
                <p><strong>${getPopupLabel('usuarios', currentLang)}</strong> ${getTranslatedValue(info.usuarios, currentLang)}</p>
                <p><strong>${getPopupLabel('descricao', currentLang)}</strong> ${getTranslatedValue(info.descricao, currentLang)}</p>
            </div>
        </div>
    `;
    
    document.body.appendChild(overlay);
    
    // Animar a entrada
    setTimeout(() => {
        overlay.classList.add('active');
    }, 10);
    
    // Fechar ao clicar no botão X
    const fecharBtn = overlay.querySelector('.fechar-popup');
    fecharBtn.addEventListener('click', fecharPopup);
    
    // Fechar ao clicar fora do conteúdo
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            fecharPopup();
        }
    });
    
    // Fechar com a tecla ESC
    function handleEscKey(e) {
        if (e.key === 'Escape') {
            fecharPopup();
        }
    }
    document.addEventListener('keydown', handleEscKey);
    
    function fecharPopup() {
        overlay.classList.remove('active');
        setTimeout(() => {
            if (document.body.contains(overlay)) {
                document.body.removeChild(overlay);
            }
            document.removeEventListener('keydown', handleEscKey);
        }, 300);
    }
}

// Função auxiliar para obter valores traduzidos
function getTranslatedValue(value, lang) {
    if (typeof value === 'object' && value !== null) {
        return value[lang] || value['pt'] || value;
    }
    return value;
}

// Função auxiliar para obter labels dos pop-ups
function getPopupLabel(key, lang) {
    const labels = {
        'criador': {
            'pt': 'Criador:',
            'en': 'Creator:'
        },
        'ano_criacao': {
            'pt': 'Ano de Criação:',
            'en': 'Creation Year:'
        },
        'usuarios': {
            'pt': 'Usuários Ativos:',
            'en': 'Active Users:'
        },
        'descricao': {
            'pt': 'Descrição:',
            'en': 'Description:'
        }
    };
    
    return labels[key]?.[lang] || labels[key]?.['pt'] || key;
}

// Animação de scroll para a página de Redes Sociais
document.addEventListener('DOMContentLoaded', function() {
    const elementos = {
        titulo: document.querySelector('.redes-titulo'),
        linha1: document.querySelector('.redes-linha:nth-child(2)'),
        divisor: document.querySelector('.redes-divider'),
        linha2: document.querySelector('.redes-linha:nth-child(4)'),
        itens: document.querySelectorAll('.rede-item-com-imagem')
    };

    // Registrar elementos específicos desta página para tradução
    registerPageSpecificElements();
    
    // Adicionar event listeners aos itens clicáveis
    elementos.itens.forEach(item => {
        const nomeRede = item.querySelector('.rede-nome').textContent.toLowerCase();
        item.addEventListener('click', () => abrirPopup(nomeRede));
        item.style.cursor = 'pointer';
    });

    // Aplicar traduções quando o idioma mudar
    document.addEventListener('languageChanged', function(event) {
        updatePopupContent(event.detail.language);
    });

    function verificarScroll() {
        const windowHeight = window.innerHeight;
        const triggerBottom = windowHeight * 0.85;

        // Animar elementos principais
        if (elementos.titulo) {
            const tituloTop = elementos.titulo.getBoundingClientRect().top;
            if (tituloTop < triggerBottom) {
                elementos.titulo.classList.add('visible');
            } else {
                elementos.titulo.classList.remove('visible');
            }
        }

        if (elementos.linha1) {
            const linha1Top = elementos.linha1.getBoundingClientRect().top;
            if (linha1Top < triggerBottom) {
                elementos.linha1.classList.add('visible');
            } else {
                elementos.linha1.classList.remove('visible');
            }
        }

        if (elementos.divisor) {
            const divisorTop = elementos.divisor.getBoundingClientRect().top;
            if (divisorTop < triggerBottom) {
                elementos.divisor.classList.add('visible');
            } else {
                elementos.divisor.classList.remove('visible');
            }
        }

        if (elementos.linha2) {
            const linha2Top = elementos.linha2.getBoundingClientRect().top;
            if (linha2Top < triggerBottom) {
                elementos.linha2.classList.add('visible');
            } else {
                elementos.linha2.classList.remove('visible');
            }
        }

        // Animar itens com imagens com delay
        elementos.itens.forEach((item, index) => {
            const itemTop = item.getBoundingClientRect().top;
            
            if (itemTop < triggerBottom) {
                setTimeout(() => {
                    item.classList.add('visible');
                }, index * 200);
            } else {
                item.classList.remove('visible');
            }
        });

        // Efeito fade out
        const section = document.querySelector('.redes-sociais-section');
        if (section) {
            const sectionBottom = section.getBoundingClientRect().bottom;
            const sectionTop = section.getBoundingClientRect().top;
            
            if (sectionTop > windowHeight || sectionBottom < 0) {
                Object.keys(elementos).forEach(key => {
                    if (elementos[key] && elementos[key].classList) {
                        if (key === 'itens') {
                            elementos.itens.forEach(item => item.classList.add('fade-out'));
                        } else {
                            elementos[key].classList.add('fade-out');
                        }
                    }
                });
            }
        }
    }

    // Registrar elementos específicos da página para tradução
    function registerPageSpecificElements() {
        if (typeof languageManager !== 'undefined') {
            // Títulos e textos da página
            languageManager.registerElementBySelector('redes_sociais_titulo', '.redes-titulo');
            languageManager.registerElementBySelector('redes_sociais_descricao', '.redes-descricao');
            languageManager.registerElementBySelector('exemplos_titulo', '.exemplos-titulo');
            
            // Nomes das redes sociais
            const redesItems = document.querySelectorAll('.rede-item-com-imagem');
            redesItems.forEach((item, index) => {
                const redeNome = item.querySelector('.rede-nome');
                if (redeNome) {
                    const redeKey = getRedeSocialKey(redeNome.textContent);
                    if (redeKey) {
                        languageManager.registerElement(redeKey, redeNome);
                    }
                }
            });
        }
    }

    // Função para mapear nomes para keys de tradução
    function getRedeSocialKey(nome) {
        const mapping = {
            'Instagram': 'instagram',
            'YouTube': 'youtube', 
            'Facebook': 'facebook',
            'WhatsApp': 'whatsapp',
            'TikTok': 'tiktok',
            'Discord': 'discord'
        };
        return mapping[nome];
    }

    // Atualizar conteúdo dos pop-ups quando idioma mudar
    function updatePopupContent(lang) {
        // Os pop-ups serão atualizados automaticamente quando reabertos
        // pois usam as funções getTranslatedValue e getPopupLabel
        console.log(`🌐 Conteúdo dos pop-ups atualizado para: ${lang}`);
        
        // Atualizar também os nomes das redes sociais nos cards
        const redesItems = document.querySelectorAll('.rede-item-com-imagem');
        redesItems.forEach(item => {
            const redeNome = item.querySelector('.rede-nome');
            if (redeNome) {
                const redeKey = getRedeSocialKey(redeNome.textContent);
                if (redeKey && languageManager) {
                    redeNome.textContent = languageManager.t(redeKey);
                }
            }
        });
    }

    // Verificar scroll inicial
    verificarScroll();

    // Adicionar event listener para scroll
    window.addEventListener('scroll', verificarScroll);
    window.addEventListener('resize', verificarScroll);
});