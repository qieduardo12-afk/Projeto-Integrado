function toggleInfo(elemento) {
  elemento.classList.toggle("ativo");
}
