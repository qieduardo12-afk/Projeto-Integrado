// languageButtons.js - ATUALIZADO
document.addEventListener('DOMContentLoaded', function() {
    const langButtons = document.querySelectorAll('.lang-btn');
    const navButtons = document.querySelectorAll('.nav-btn');
    
    // Inicializar sistema de idiomas
    initializeLanguageSystem();
    
    // Funcionalidade dos botões de idioma
    langButtons.forEach(button => {
        button.addEventListener('click', function() {
            const selectedLang = this.textContent.toLowerCase();
            
            // Não fazer nada se já está ativo
            if (this.classList.contains('active')) {
                return;
            }
            
            // Remove active de todos os botões primeiro
            langButtons.forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Adicionar animação de troca ao botão clicado
            this.classList.add('switching');
            
            // Mudar idioma após um pequeno delay para a animação
            setTimeout(() => {
                this.classList.remove('switching');
                this.classList.add('active');
                
                // Mudar idioma no sistema
                if (languageManager.changeLanguage(selectedLang)) {
                    console.log(`🌐 Idioma alterado para: ${selectedLang.toUpperCase()}`);
                }
            }, 400);
        });
    });
    
    // Funcionalidade dos botões de navegação (mantida)
    navButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent;
            
            if (buttonText === 'ABOUT' || buttonText === 'SOBRE') {
                console.log('Navegando para About/Sobre');
            } else if (buttonText === 'CONTACT' || buttonText === 'CONTATO') {
                console.log('Navegando para Contact/Contato');
            }
        });
    });
    
    function initializeLanguageSystem() {
        // Registrar elementos comuns a todas as páginas
        registerCommonElements();
        
        // Aplicar traduções iniciais
        languageManager.applyTranslations();
        
        // Ativar botão do idioma atual
        const currentLang = languageManager.currentLang;
        const activeButton = Array.from(langButtons).find(btn => 
            btn.textContent.toLowerCase() === currentLang
        );
        
        if (activeButton) {
            langButtons.forEach(btn => btn.classList.remove('active'));
            activeButton.classList.add('active');
        }
        
        console.log(`🌐 Sistema de idiomas inicializado em: ${currentLang.toUpperCase()}`);
    }
    
    function registerCommonElements() {
        // Header Navigation
        languageManager.registerElementBySelector('nav_home', '.navHeader-list a[href*="Home"]');
        languageManager.registerElementBySelector('nav_developers', '.navHeader-list a[href*="PagDevs"]');
        languageManager.registerElementBySelector('nav_timeline', '.navHeader-list a[href*="Timeline"]');
        languageManager.registerElementBySelector('nav_social_networks', '.navHeader-list a[href*="RedesSociais"]');
        languageManager.registerElementBySelector('nav_virtual_assistants', '.navHeader-list a[href*="AssistenteVirtual"]');
        languageManager.registerElementBySelector('nav_quantum_computers', '.navHeader-list a[href*="ComputadorQuantico"]');
        languageManager.registerElementBySelector('nav_android_ios', '.navHeader-list a[href*="AndroidVSIOS"]');
        languageManager.registerElementBySelector('nav_operating_systems', '.navHeader-list a[href*="Sistemas operacionais"]');
        
        // Header Buttons
        languageManager.registerElementBySelector('nav_about', '.nav-btn:nth-child(1)');
        languageManager.registerElementBySelector('nav_contact', '.nav-btn:nth-child(2)');
        
        // Footer
        languageManager.registerElementBySelector('footer_contact', '.contact-info h4');
        languageManager.registerElementBySelector('footer_instagram', '.insta-geral h4');
        languageManager.registerElementBySelector('footer_privacy', '.privacy-policy a h4');
        languageManager.registerElementBySelector('footer_terms', '.privacy-policy a p');
        languageManager.registerElementBySelector('footer_copyright', '.copyright p');
    }
});