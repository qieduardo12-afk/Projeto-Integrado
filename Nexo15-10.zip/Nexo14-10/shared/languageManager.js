// shared/languageManager.js
class LanguageManager {
    constructor() {
        this.currentLang = this.getSavedLanguage();
        this.elements = new Map();
    }
    
    getSavedLanguage() {
        return localStorage.getItem('preferredLanguage') || 'pt';
    }
    
    saveLanguage(lang) {
        localStorage.setItem('preferredLanguage', lang);
        this.currentLang = lang;
    }
    
    // Registrar elementos para tradução automática
    registerElement(key, element, attribute = 'textContent') {
        if (!this.elements.has(key)) {
            this.elements.set(key, []);
        }
        this.elements.get(key).push({ element, attribute });
    }
    
    // Registrar elemento por seletor
    registerElementBySelector(key, selector, attribute = 'textContent') {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
            this.registerElement(key, element, attribute);
        });
    }
    
    // Aplicar traduções
    applyTranslations() {
        const langData = translations[this.currentLang];
        
        this.elements.forEach((elements, key) => {
            if (langData[key]) {
                elements.forEach(({ element, attribute }) => {
                    if (attribute === 'textContent') {
                        element.textContent = langData[key];
                    } else if (attribute === 'placeholder') {
                        element.placeholder = langData[key];
                    } else if (attribute === 'title') {
                        element.title = langData[key];
                    } else if (attribute === 'innerHTML') {
                        element.innerHTML = langData[key];
                    }
                });
            }
        });
        
        // Atualizar atributo lang do HTML
        document.documentElement.lang = this.currentLang;
        
        // Disparar evento customizado
        document.dispatchEvent(new CustomEvent('languageChanged', {
            detail: { language: this.currentLang }
        }));
    }
    
    // Mudar idioma
    changeLanguage(lang) {
        if (translations[lang]) {
            this.saveLanguage(lang);
            this.applyTranslations();
            return true;
        }
        return false;
    }
    
    // Obter texto traduzido
    t(key) {
        return translations[this.currentLang]?.[key] || key;
    }
}

// Instância global
const languageManager = new LanguageManager();