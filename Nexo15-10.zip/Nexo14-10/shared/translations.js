// shared/translations.js - ARQUIVO COMPLETO CORRIGIDO
const translations = {
    'pt': {
        // Header
        'nav_home': 'Página Inicial',
        'nav_developers': 'Página dos Desenvolvedores',
        'nav_timeline': 'Linha do Tempo',
        'nav_social_networks': 'Redes Sociais',
        'nav_virtual_assistants': 'Assistentes Virtuais',
        'nav_quantum_computers': 'Computadores Quânticos',
        'nav_android_ios': 'Android e IOS',
        'nav_operating_systems': 'Sistemas Operacionais',
        'nav_about': 'SOBRE',
        'nav_contact': 'CONTATO',
        
        // Footer
        'footer_contact': 'Nos Contate:',
        'footer_phone': '55 11 919444566',
        'footer_email': 'Nexo1676@gmail.com.br',
        'footer_instagram': 'Instagram:',
        'footer_privacy': 'Políticas de privacidade',
        'footer_terms': 'Termos de condição',
        'footer_copyright': 'Copyright © 2025 Nexo',
        
        // Redes Sociais
        'redes_sociais_titulo': 'Redes Sociais',
        'redes_sociais_descricao': 'Redes sociais são plataformas online para conexão e compartilhamento de informações, ideias, fotos e vídeos, promovendo interações entre pessoas. Elas atuam como praças digitais onde amigos e desconhecidos trocam novidades e formam comunidades.',
        'exemplos_titulo': 'Exemplos de redes sociais:',
        'instagram': 'Instagram',
        'youtube': 'YouTube',
        'facebook': 'Facebook',
        'whatsapp': 'WhatsApp',
        'tiktok': 'TikTok',
        'discord': 'Discord',
        
        // Pop-ups Redes Sociais
        'popup_criador': 'Criador:',
        'popup_ano_criacao': 'Ano de Criação:',
        'popup_usuarios': 'Usuários Ativos:',
        'popup_descricao': 'Descrição:',
        
        // Assistentes Virtuais - NOVAS TRADUÇÕES
        'assistentes_virtuais_titulo': 'Assistentes Virtuais',
        'assistentes_descricao': 'Programas que entendem linguagem natural e realizam ações — baseados em IA, PLN e machine learning. Rápido, prático e cada vez mais presente.',
        'saiba_mais_btn': 'Saiba Mais',
        'oq_sao_titulo': 'O que são assistentes virtuais ?',
        'oq_sao_descricao': 'Assistentes virtuais são programas de computador que usam inteligência artificial para interagir com pessoas, responder perguntas, executar tarefas e fornecer informações. Eles podem funcionar por texto ou por voz. Seu objetivo é facilitar a vida do usuário, automatizando tarefas, ajudando na organização e fornecendo suporte rápido e personalizado.',
        'beneficios_titulo': 'Benefícios',
        'beneficios_desc': 'Economizam tempo, automatizam tarefas e ajudam na organização do dia a dia, tornando sua rotina mais prática e eficiente.',
        'historia_titulo': 'História',
        'historia_desc': 'Dos primeiros chatbots, como ELIZA nos anos 60, até assistentes modernos em nuvem, a tecnologia evoluiu com IA e computação em nuvem.',
        'aplicacoes_titulo': 'Aplicações',
        'aplicacoes_desc': 'Atuam em produtividade, educação, acessibilidade e casas inteligentes, podendo ser por voz, texto ou híbridos integrados a dispositivos.',
        'linha_tempo_titulo': 'Linha do Tempo',
        'timeline_1960': '1960s — ELIZA',
        'timeline_1960_desc': 'Experimento inicial em chatbots.',
        'timeline_2000': '2000s — Reconhecimento de voz',
        'timeline_2000_desc': 'Integração com internet e dispositivos.',
        'timeline_2011': '2011 — Siri',
        'timeline_2011_desc': 'Popularização em smartphones.',
        'timeline_hoje': 'Hoje — Assistentes na nuvem',
        'timeline_hoje_desc': 'Modelos maiores e integração omnipresente.',
        'como_funcionam_titulo': 'Como funcionam (detalhado)',
        'como_funcionam_item1': 'Captura: microfone/teclado — pré-processamento de áudio.',
        'como_funcionam_item2': 'PLN: detecção de intenção, extração de entidades.',
        'como_funcionam_item3': 'Decisão: regras, modelos e ferramentas de diálogo.',
        'como_funcionam_item4': 'Ação: TTS, APIs e controle de dispositivos.',
        'aplicacoes_detalhes_titulo': 'Aplicações',
        'app_lembretes': 'Lembretes & Produtividade',
        'app_casa_inteligente': 'Casa Inteligente',
        'app_educacao': 'Educação',
        'app_acessibilidade': 'Acessibilidade',
        
        // Textos gerais
        'title_nexo': 'Nexo',
        'loading': 'Carregando...',
        'read_more': 'Saiba mais',
        'view_details': 'Ver detalhes'
    },
    
    'en': {
        // Header
        'nav_home': 'Home Page',
        'nav_developers': 'Developers Page',
        'nav_timeline': 'Timeline',
        'nav_social_networks': 'Social Networks',
        'nav_virtual_assistants': 'Virtual Assistants',
        'nav_quantum_computers': 'Quantum Computers',
        'nav_android_ios': 'Android and IOS',
        'nav_operating_systems': 'Operating Systems',
        'nav_about': 'ABOUT',
        'nav_contact': 'CONTACT',
        
        // Footer
        'footer_contact': 'Contact Us:',
        'footer_phone': '55 11 919444566',
        'footer_email': 'Nexo1676@gmail.com.br',
        'footer_instagram': 'Instagram:',
        'footer_privacy': 'Privacy Policy',
        'footer_terms': 'Terms and Conditions',
        'footer_copyright': 'Copyright © 2025 Nexo',
        
        // Social Networks
        'redes_sociais_titulo': 'Social Networks',
        'redes_sociais_descricao': 'Social networks are online platforms for connection and sharing of information, ideas, photos and videos, promoting interactions between people. They act as digital squares where friends and strangers exchange news and form communities.',
        'exemplos_titulo': 'Examples of social networks:',
        'instagram': 'Instagram',
        'youtube': 'YouTube',
        'facebook': 'Facebook',
        'whatsapp': 'WhatsApp',
        'tiktok': 'TikTok',
        'discord': 'Discord',
        
        // Social Networks Pop-ups
        'popup_criador': 'Creator:',
        'popup_ano_criacao': 'Creation Year:',
        'popup_usuarios': 'Active Users:',
        'popup_descricao': 'Description:',
        
        // Virtual Assistants - NEW TRANSLATIONS
        'assistentes_virtuais_titulo': 'Virtual Assistants',
        'assistentes_descricao': 'Programs that understand natural language and perform actions — based on AI, NLP and machine learning. Fast, practical and increasingly present.',
        'saiba_mais_btn': 'Learn More',
        'oq_sao_titulo': 'What are virtual assistants?',
        'oq_sao_descricao': 'Virtual assistants are computer programs that use artificial intelligence to interact with people, answer questions, perform tasks and provide information. They can work by text or voice. Their goal is to make the user life easier by automating tasks, helping with organization and providing quick and personalized support.',
        'beneficios_titulo': 'Benefits',
        'beneficios_desc': 'They save time, automate tasks and help with daily organization, making your routine more practical and efficient.',
        'historia_titulo': 'History',
        'historia_desc': 'From early chatbots like ELIZA in the 60s to modern cloud assistants, technology has evolved with AI and cloud computing.',
        'aplicacoes_titulo': 'Applications',
        'aplicacoes_desc': 'They work in productivity, education, accessibility and smart homes, and can be voice, text or hybrid integrated with devices.',
        'linha_tempo_titulo': 'Timeline',
        'timeline_1960': '1960s — ELIZA',
        'timeline_1960_desc': 'Initial experiment in chatbots.',
        'timeline_2000': '2000s — Voice recognition',
        'timeline_2000_desc': 'Integration with internet and devices.',
        'timeline_2011': '2011 — Siri',
        'timeline_2011_desc': 'Popularization in smartphones.',
        'timeline_hoje': 'Today — Cloud assistants',
        'timeline_hoje_desc': 'Larger models and ubiquitous integration.',
        'como_funcionam_titulo': 'How they work (detailed)',
        'como_funcionam_item1': 'Capture: microphone/keyboard — audio preprocessing.',
        'como_funcionam_item2': 'NLP: intent detection, entity extraction.',
        'como_funcionam_item3': 'Decision: rules, models and dialogue tools.',
        'como_funcionam_item4': 'Action: TTS, APIs and device control.',
        'aplicacoes_detalhes_titulo': 'Applications',
        'app_lembretes': 'Reminders & Productivity',
        'app_casa_inteligente': 'Smart Home',
        'app_educacao': 'Education',
        'app_acessibilidade': 'Accessibility',
        
        // General texts
        'title_nexo': 'Nexo',
        'loading': 'Loading...',
        'read_more': 'Read more',
        'view_details': 'View details'
    }
};